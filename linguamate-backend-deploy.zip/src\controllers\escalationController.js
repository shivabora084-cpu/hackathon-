import { supabase } from '../database/supabaseClient.js';

export const createEscalation = async (req, res, next) => {
  try {
    const { conversationId, issueSummary, escalationReason, urgency = 'medium', preferredLanguage = 'en' } = req.body;
    const userId = req.user.id;

    if (supabase) {
      const { data, error } = await supabase
        .from('escalations')
        .insert({
          conversation_id: conversationId,
          user_id: userId,
          issue_summary: issueSummary,
          escalation_reason: escalationReason,
          urgency,
          preferred_language: preferredLanguage,
          status: 'pending',
        })
        .select()
        .single();

      if (error) throw error;

      // Log to analytics
      await supabase.from('analytics_events').insert({
        user_id: userId,
        event_type: 'escalation',
        language: preferredLanguage,
        metadata: { urgency, reason: escalationReason },
      });

      return res.status(201).json({
        success: true,
        message: 'Your request for a human representative has been queued. An agent will assist you.',
        escalation: data,
      });
    }

    return res.status(201).json({
      success: true,
      message: 'Support escalation created (local)',
      escalation: { id: 'mock-esc-' + Date.now(), issueSummary, urgency, status: 'pending' },
    });
  } catch (err) {
    next(err);
  }
};

export const getEscalations = async (req, res, next) => {
  try {
    const { status } = req.query;

    if (supabase) {
      let query = supabase
        .from('escalations')
        .select('*, profiles:user_id(full_name, email)')
        .order('created_at', { ascending: false });

      if (status) {
        query = query.eq('status', status);
      }

      const { data, error } = await query;
      if (error) throw error;
      return res.json({ success: true, escalations: data || [] });
    }

    return res.json({ success: true, escalations: [] });
  } catch (err) {
    next(err);
  }
};

export const updateEscalationStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, resolutionNotes } = req.body;
    const agentId = req.user.id;

    if (supabase) {
      const { data, error } = await supabase
        .from('escalations')
        .update({
          status,
          resolution_notes: resolutionNotes,
          assigned_agent_id: agentId,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return res.json({ success: true, escalation: data });
    }

    return res.json({ success: true });
  } catch (err) {
    next(err);
  }
};
