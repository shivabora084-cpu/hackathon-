import { supabase } from '../database/supabaseClient.js';

export const createConversation = async (req, res, next) => {
  try {
    const { title = 'New Conversation', language = 'en' } = req.body;
    const userId = req.user.id;

    if (supabase) {
      const { data, error } = await supabase
        .from('conversations')
        .insert({ user_id: userId, title, language })
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json({ success: true, conversation: data });
    }

    return res.status(201).json({
      success: true,
      conversation: { id: 'mock-' + Date.now(), user_id: userId, title, language, created_at: new Date() },
    });
  } catch (err) {
    next(err);
  }
};

export const getConversations = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { savedOnly } = req.query;

    if (supabase) {
      let query = supabase
        .from('conversations')
        .select('*, messages(count)')
        .eq('user_id', userId)
        .order('updated_at', { ascending: false });

      if (savedOnly === 'true') {
        query = query.eq('is_saved', true);
      }

      const { data, error } = await query;
      if (error) throw error;
      return res.json({ success: true, conversations: data || [] });
    }

    return res.json({ success: true, conversations: [] });
  } catch (err) {
    next(err);
  }
};

export const getConversationById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    if (supabase) {
      const { data: conversation, error: convErr } = await supabase
        .from('conversations')
        .select('*')
        .eq('id', id)
        .eq('user_id', userId)
        .single();

      if (convErr || !conversation) {
        return res.status(404).json({ success: false, error: 'Conversation not found or unauthorized' });
      }

      const { data: messages, error: msgErr } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', id)
        .order('created_at', { ascending: true });

      if (msgErr) throw msgErr;

      return res.json({
        success: true,
        conversation,
        messages: messages || [],
      });
    }

    return res.status(404).json({ success: false, error: 'Conversation not found' });
  } catch (err) {
    next(err);
  }
};

export const deleteConversation = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    if (supabase) {
      const { error } = await supabase
        .from('conversations')
        .delete()
        .eq('id', id)
        .eq('user_id', userId);

      if (error) throw error;
      return res.json({ success: true, message: 'Conversation deleted successfully' });
    }

    return res.json({ success: true, message: 'Conversation deleted (local)' });
  } catch (err) {
    next(err);
  }
};

export const toggleSaveConversation = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const { isSaved } = req.body;

    if (supabase) {
      const { data, error } = await supabase
        .from('conversations')
        .update({ is_saved: isSaved, updated_at: new Date().toISOString() })
        .eq('id', id)
        .eq('user_id', userId)
        .select()
        .single();

      if (error) throw error;
      return res.json({ success: true, conversation: data });
    }

    return res.json({ success: true });
  } catch (err) {
    next(err);
  }
};
