import { supabase } from '../database/supabaseClient.js';
import {
  analyzeUserMessage,
  generateChatResponse,
} from '../services/geminiService.js';
import { retrieveRelevantContext } from '../services/ragService.js';

export const handleChatMessage = async (req, res, next) => {
  const startTime = Date.now();
  try {
    const { text, language = 'en', inputType = 'text' } = req.body;
    let conversationId = req.body.conversationId;
    const userId = req.user?.id || null;

    let conversationHistory = [];

    // 1. Resolve or create conversation
    if (supabase && userId) {
      if (!conversationId) {
        const { data: newConv, error: convErr } = await supabase
          .from('conversations')
          .insert({
            user_id: userId,
            title: text.substring(0, 40) + (text.length > 40 ? '...' : ''),
            language,
          })
          .select()
          .single();

        if (convErr) throw convErr;
        conversationId = newConv.id;
      } else {
        // Fetch existing history
        const { data: hist } = await supabase
          .from('messages')
          .select('*')
          .eq('conversation_id', conversationId)
          .order('created_at', { ascending: true })
          .limit(10);

        if (hist) conversationHistory = hist;
      }
    } else if (!conversationId) {
      conversationId = 'conv-' + Date.now();
    }

    // 2. Perform linguistic and intent analysis (Mixed-language, sentiment, urgency, ambiguity)
    const analysis = await analyzeUserMessage(text, conversationHistory);

    // 3. Check for grounded document context if relevant
    let ragResult = { contextText: '', sources: [] };
    if (analysis.intent !== 'human_escalation' && !analysis.isClarificationNeeded) {
      ragResult = await retrieveRelevantContext(text);
    }

    // 4. Determine response: Clarification vs Contextual Answer
    let aiResponseText = '';
    let followUpSuggestions = [];
    let isClarification = false;
    let clarificationOptions = [];

    if (analysis.isClarificationNeeded && analysis.clarificationPrompt) {
      isClarification = true;
      aiResponseText = analysis.clarificationPrompt;
      clarificationOptions = analysis.clarificationOptions || [];
      followUpSuggestions = clarificationOptions;
    } else {
      const generated = await generateChatResponse({
        conversationHistory,
        userMessage: text,
        preferredLanguage: language,
        documentContext: ragResult.contextText,
      });

      aiResponseText = generated.text;
      followUpSuggestions = generated.followUpSuggestions;
    }

    // 5. Save messages to Supabase if DB is connected
    let userMsgId = null;
    let assistantMsgId = null;

    if (supabase && conversationId) {
      // Save User message
      const { data: savedUserMsg } = await supabase
        .from('messages')
        .insert({
          conversation_id: conversationId,
          sender: 'user',
          text,
          detected_language: analysis.detectedLanguage,
          mixed_languages: analysis.mixedLanguages,
          intent: analysis.intent,
          sentiment: analysis.sentiment,
          urgency: analysis.urgency,
        })
        .select()
        .single();

      if (savedUserMsg) userMsgId = savedUserMsg.id;

      // Save Assistant message
      const { data: savedAssistantMsg } = await supabase
        .from('messages')
        .insert({
          conversation_id: conversationId,
          sender: 'assistant',
          text: aiResponseText,
          detected_language: language,
          is_clarification: isClarification,
          clarification_options: clarificationOptions,
          source_documents: ragResult.sources,
        })
        .select()
        .single();

      if (savedAssistantMsg) assistantMsgId = savedAssistantMsg.id;

      // Log analytics event
      const latencyMs = Date.now() - startTime;
      await supabase.from('analytics_events').insert({
        user_id: userId,
        event_type: 'chat_message',
        language: analysis.detectedLanguage,
        input_type: inputType,
        latency_ms: latencyMs,
        metadata: {
          intent: analysis.intent,
          mixed_languages: analysis.mixedLanguages,
          has_rag: ragResult.sources.length > 0,
        },
      });
    }

    // 6. Return comprehensive structured response
    return res.json({
      success: true,
      conversationId,
      messageId: assistantMsgId,
      userMessageId: userMsgId,
      response: {
        text: aiResponseText,
        detectedLanguage: analysis.detectedLanguage,
        mixedLanguages: analysis.mixedLanguages,
        intent: analysis.intent,
        sentiment: analysis.sentiment,
        urgency: analysis.urgency,
        isClarification,
        clarificationOptions,
        followUpSuggestions,
        sourceDocuments: ragResult.sources,
      },
      latencyMs: Date.now() - startTime,
    });
  } catch (err) {
    next(err);
  }
};
