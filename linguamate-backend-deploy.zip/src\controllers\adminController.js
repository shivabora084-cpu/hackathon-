import { supabase, testDatabaseConnection } from '../database/supabaseClient.js';
import { testGeminiConnection } from '../services/geminiService.js';
import { getSpeechCapabilities } from '../services/speechAdapter.js';

export const getAnalytics = async (req, res, next) => {
  try {
    if (supabase) {
      // 1. Total counts
      const [
        { count: userCount },
        { count: conversationCount },
        { count: messageCount },
        { count: documentCount },
        { count: escalationCount },
      ] = await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact', head: true }),
        supabase.from('conversations').select('*', { count: 'exact', head: true }),
        supabase.from('messages').select('*', { count: 'exact', head: true }),
        supabase.from('knowledge_documents').select('*', { count: 'exact', head: true }),
        supabase.from('escalations').select('*', { count: 'exact', head: true }),
      ]);

      // 2. Language breakdown from messages
      const { data: messages } = await supabase
        .from('messages')
        .select('detected_language')
        .not('detected_language', 'is', null)
        .limit(200);

      const languageCounts = {};
      if (messages) {
        messages.forEach((m) => {
          const lang = m.detected_language || 'en';
          languageCounts[lang] = (languageCounts[lang] || 0) + 1;
        });
      }

      // 3. Feedback average
      const { data: feedbackData } = await supabase
        .from('feedback')
        .select('rating');

      let avgRating = 0;
      if (feedbackData && feedbackData.length > 0) {
        const sum = feedbackData.reduce((acc, f) => acc + (f.rating || 0), 0);
        avgRating = Number((sum / feedbackData.length).toFixed(1));
      }

      // 4. Recent escalations
      const { data: recentEscalations } = await supabase
        .from('escalations')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);

      // 5. Recent events
      const { data: recentEvents } = await supabase
        .from('analytics_events')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      return res.json({
        success: true,
        metrics: {
          totalUsers: userCount || 0,
          totalConversations: conversationCount || 0,
          totalMessages: messageCount || 0,
          totalDocuments: documentCount || 0,
          totalEscalations: escalationCount || 0,
          averageFeedbackRating: avgRating,
          feedbackCount: feedbackData?.length || 0,
          languageDistribution: languageCounts,
        },
        recentEscalations: recentEscalations || [],
        recentEvents: recentEvents || [],
      });
    }

    // Default mock stats if database is not yet populated
    return res.json({
      success: true,
      metrics: {
        totalUsers: 1,
        totalConversations: 0,
        totalMessages: 0,
        totalDocuments: 0,
        totalEscalations: 0,
        averageFeedbackRating: 5.0,
        feedbackCount: 0,
        languageDistribution: { en: 1 },
      },
      recentEscalations: [],
      recentEvents: [],
    });
  } catch (err) {
    next(err);
  }
};

export const getAllUsers = async (req, res, next) => {
  try {
    if (supabase) {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, full_name, role, preferred_language, created_at')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return res.json({ success: true, users: data || [] });
    }
    return res.json({ success: true, users: [] });
  } catch (err) {
    next(err);
  }
};

export const getAllConversations = async (req, res, next) => {
  try {
    if (supabase) {
      const { data, error } = await supabase
        .from('conversations')
        .select('*, profiles:user_id(full_name, email), messages(count)')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      return res.json({ success: true, conversations: data || [] });
    }
    return res.json({ success: true, conversations: [] });
  } catch (err) {
    next(err);
  }
};

export const getSystemHealth = async (req, res, next) => {
  try {
    const dbStatus = await testDatabaseConnection();
    const aiStatus = await testGeminiConnection();
    const speechStatus = getSpeechCapabilities();

    return res.json({
      success: true,
      timestamp: new Date().toISOString(),
      uptimeSeconds: Math.floor(process.uptime()),
      database: dbStatus,
      aiEngine: aiStatus,
      speechServices: speechStatus,
    });
  } catch (err) {
    next(err);
  }
};
