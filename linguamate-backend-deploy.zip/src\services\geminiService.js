import { GoogleGenerativeAI } from '@google/generative-ai';
import { config } from '../config/index.js';

let genAI = null;
let modelInstance = null;
let embeddingModelInstance = null;

if (config.gemini.apiKey) {
  try {
    genAI = new GoogleGenerativeAI(config.gemini.apiKey);
    modelInstance = genAI.getGenerativeModel({
      model: config.gemini.model,
      generationConfig: {
        temperature: 0.4,
        topP: 0.9,
        maxOutputTokens: 2048,
      },
    });
    embeddingModelInstance = genAI.getGenerativeModel({
      model: 'gemini-embedding-001',
    });
  } catch (err) {
    console.error('[Gemini Service] Initialization error:', err.message);
  }
}

/**
 * Safely extract and parse JSON from a Gemini response string.
 * Handles markdown fences (```json...```), leading/trailing text, and
 * multi-line string values that break a naive JSON.parse().
 */
function safeParseJSON(raw) {
  // 1. Strip markdown code fences
  let cleaned = raw
    .replace(/```json\s*/gi, '')
    .replace(/```\s*/g, '')
    .trim();

  // 2. Extract the first complete JSON object or array using a brace-counting approach
  const firstBrace = cleaned.indexOf('{');
  const firstBracket = cleaned.indexOf('[');

  let startIdx = -1;
  let openChar, closeChar;

  if (firstBrace === -1 && firstBracket === -1) {
    throw new Error('No JSON object or array found in response');
  } else if (firstBrace === -1) {
    startIdx = firstBracket; openChar = '['; closeChar = ']';
  } else if (firstBracket === -1) {
    startIdx = firstBrace; openChar = '{'; closeChar = '}';
  } else {
    startIdx = Math.min(firstBrace, firstBracket);
    openChar = cleaned[startIdx] === '{' ? '{' : '[';
    closeChar = openChar === '{' ? '}' : ']';
  }

  let depth = 0;
  let endIdx = -1;
  let inString = false;
  let escape = false;

  for (let i = startIdx; i < cleaned.length; i++) {
    const ch = cleaned[i];
    if (escape) { escape = false; continue; }
    if (ch === '\\' && inString) { escape = true; continue; }
    if (ch === '"') { inString = !inString; continue; }
    if (inString) continue;
    if (ch === openChar) depth++;
    if (ch === closeChar) {
      depth--;
      if (depth === 0) { endIdx = i; break; }
    }
  }

  if (endIdx === -1) {
    // Fallback: try parsing the whole cleaned string as-is
    return JSON.parse(cleaned);
  }

  const jsonSubstring = cleaned.slice(startIdx, endIdx + 1);
  return JSON.parse(jsonSubstring);
}

/**
 * Health check for Gemini API
 */
export const testGeminiConnection = async () => {
  if (!config.gemini.apiKey || !modelInstance) {
    return {
      connected: false,
      message: 'GEMINI_API_KEY is not configured in backend environment variables.',
    };
  }

  try {
    const result = await modelInstance.generateContent('ping');
    const response = await result.response;
    return {
      connected: true,
      message: 'Successfully connected to Google Gemini API.',
      sampleResponse: response.text().trim(),
    };
  } catch (error) {
    return {
      connected: false,
      message: `Gemini API connection error: ${error.message}`,
      error,
    };
  }
};

/**
 * Detect language, code-mixing, sentiment, urgency and clarification needs
 */
export const analyzeUserMessage = async (text, recentHistory = []) => {
  const lower = text.toLowerCase();
  const isAmbiguous = lower === 'cancel it' || lower === 'open account' || lower === 'help' || lower === 'cancel';
  const isTamilMixed = /evlo|venum|illai|nalla|panren|panna|irukka/i.test(lower);
  const isHindiMixed = /jaana|hai|kya|bhai|paisa|karna|lana/i.test(lower);

  if (!modelInstance) {
    return {
      detectedLanguage: isTamilMixed ? 'ta' : isHindiMixed ? 'hi' : 'en',
      mixedLanguages: isTamilMixed ? ['ta', 'en'] : isHindiMixed ? ['hi', 'en'] : ['en'],
      intent: lower.includes('human') || lower.includes('agent')
        ? 'human_escalation'
        : lower.includes('fee') || isTamilMixed
        ? 'fee_inquiry'
        : 'general_inquiry',
      sentiment: lower.includes('frustrat') || lower.includes('angry') ? 'frustrated' : 'neutral',
      urgency: lower.includes('urgent') || lower.includes('immediate') ? 'high' : 'low',
      isClarificationNeeded: isAmbiguous,
      clarificationPrompt: isAmbiguous ? 'Which service or request would you like to cancel?' : null,
      clarificationOptions: isAmbiguous ? ['Academic Service', 'Account Settings', 'Billing / Fees'] : [],
    };
  }

  const prompt = `You are the intent and linguistic analyzer for LinguaMate AI.
Analyze the following user input in the context of recent conversation history.

Recent Context:
${recentHistory.map((m) => `${m.sender}: ${m.text}`).slice(-3).join('\n')}

User Input: "${text}"

Respond ONLY with a valid JSON object matching this schema without markdown fences:
{
  "detectedLanguage": "primary language code (e.g. en, ta, hi, te, ml, kn, bn)",
  "mixedLanguages": ["array of language codes if mixed e.g. ta and en for Tanglish"],
  "intent": "general_inquiry | college_admission | fee_payment | document_request | clarification_reply | cancel_service | technical_support | human_escalation",
  "sentiment": "satisfied | neutral | confused | frustrated",
  "urgency": "low | medium | high | critical",
  "isClarificationNeeded": true or false,
  "clarificationPrompt": "Question to clarify if user input is ambiguous (e.g. 'Cancel it' -> 'Which request or application would you like to cancel?'), or null if clear",
  "clarificationOptions": ["Option A", "Option B"] or []
}`;

  try {
    const result = await modelInstance.generateContent(prompt);
    return safeParseJSON(result.response.text());
  } catch (err) {
    console.warn('[Gemini Analyze] Fallback to heuristic parser:', err.message);
    const lower = text.toLowerCase();
    const isAmbiguous = lower === 'cancel it' || lower === 'open account' || lower === 'help' || lower === 'cancel';
    const isTamilMixed = /evlo|venum|illai|nalla|panren|panna/i.test(lower);
    const isHindiMixed = /jaana|hai|kya|bhai|paisa|karna/i.test(lower);

    return {
      detectedLanguage: isTamilMixed ? 'ta' : isHindiMixed ? 'hi' : 'en',
      mixedLanguages: isTamilMixed ? ['ta', 'en'] : isHindiMixed ? ['hi', 'en'] : ['en'],
      intent: lower.includes('human') || lower.includes('agent') ? 'human_escalation' : 'general_inquiry',
      sentiment: lower.includes('frustrat') || lower.includes('angry') ? 'frustrated' : 'neutral',
      urgency: lower.includes('urgent') || lower.includes('immediate') ? 'high' : 'low',
      isClarificationNeeded: isAmbiguous,
      clarificationPrompt: isAmbiguous ? 'Could you please specify which service or item you are referring to?' : null,
      clarificationOptions: isAmbiguous ? ['Academic Service', 'Account Settings', 'Billing / Fees'] : [],
    };
  }
};

/**
 * Generate contextual conversational AI response
 */
export const generateChatResponse = async ({
  conversationHistory = [],
  userMessage,
  preferredLanguage = 'en',
  documentContext = '',
  userPreferences = {},
}) => {
  if (!modelInstance) {
    return {
      text: "I am ready to help! To enable full conversational AI with Gemini, please set GEMINI_API_KEY in backend/.env.",
      detectedLanguage: preferredLanguage,
      followUpSuggestions: ["What can LinguaMate AI do?", "How do I upload documents?", "Try a voice conversation"],
      sourceDocuments: [],
    };
  }

  const systemInstruction = `You are LinguaMate AI: "Beyond Translation. Understand Every Conversation."
You are an intelligent multilingual communication assistant.
Core Capabilities:
1. Understand mixed languages naturally (e.g., Tanglish: "Sir, admission fees evlo?", Hinglish: "Kal college jaana hai, what is the timing?").
2. Retain conversation context (e.g. resolve references like "it", "that", "the fee", "the timing" from earlier turns).
3. Ground your answers strictly in the verified Document Knowledge Base when provided. If the information is in the documents, cite the source. Never hallucinate missing facts.
4. Respond in the user's preferred language (${preferredLanguage}) with natural, conversational fluency.
5. If the request is ambiguous, ask a polite clarification question instead of making false assumptions.
6. Provide 2-3 helpful, short follow-up suggestions.

${documentContext ? `VERIFIED KNOWLEDGE BASE CONTEXT:\n${documentContext}\n` : ''}
`;

  const formattedHistory = conversationHistory
    .slice(-8)
    .map((m) => `${m.sender === 'user' ? 'User' : 'Assistant'}: ${m.text}`)
    .join('\n');

  const fullPrompt = `${systemInstruction}

Conversation History:
${formattedHistory}

Current User Message: ${userMessage}

Respond in the following JSON format only, without markdown code fences:
{
  "text": "Your helpful response here in the appropriate language",
  "followUpSuggestions": ["Short question 1", "Short question 2", "Short question 3"],
  "sourceReferences": ["Document name and section cited if applicable"]
}`;

  try {
    const result = await modelInstance.generateContent(fullPrompt);
    const parsed = safeParseJSON(result.response.text());
    return {
      text: parsed.text || result.response.text().trim(),
      followUpSuggestions: parsed.followUpSuggestions || [],
      sourceDocuments: parsed.sourceReferences || [],
    };
  } catch (err) {
    console.warn('[Gemini Chat JSON parse failed, retrying plain]:', err.message);
    try {
      // Fallback: ask for plain text, no JSON wrapper
      const historyLines = conversationHistory
        .slice(-8)
        .map((m) => `${m.sender === 'user' ? 'User' : 'Assistant'}: ${m.text}`)
        .join('\n');
      const result = await modelInstance.generateContent(
        `${systemInstruction}\nConversation History:\n${historyLines}\n\nUser: ${userMessage}\nAssistant (respond helpfully in ${preferredLanguage}):`
      );
      const plainText = result.response.text().trim();
      return {
        text: plainText,
        followUpSuggestions: ['Can you explain more?', 'What are the next steps?', 'Can you give an example?'],
        sourceDocuments: [],
      };
    } catch (fallbackErr) {
      return {
        text: `I'm having trouble reaching the AI engine right now. Please try again in a moment. (${fallbackErr.message})`,
        followUpSuggestions: [],
        sourceDocuments: [],
      };
    }
  }
};

/**
 * Contextual translation with cultural context, idioms, and formality options
 */
export const translateAndExplain = async ({
  text,
  targetLanguage = 'en',
  sourceLanguage = 'auto',
  formality = 'auto',
}) => {
  if (!modelInstance) {
    return {
      translatedText: text,
      literalTranslation: text,
      intendedMeaning: 'Please configure GEMINI_API_KEY to enable AI contextual translation.',
      formalityLevel: formality,
      culturalContext: 'AI key required for cultural breakdown.',
      alternativePhrases: [],
    };
  }

  const prompt = `You are LinguaMate AI's Contextual Translation and Cultural Explanation Engine.
Translate and explain the following text for real-world conversational understanding:

Input Text: "${text}"
Target Language: "${targetLanguage}"
Source Language: "${sourceLanguage}"
Preferred Formality: "${formality}"

Analyze whether there are idioms (e.g. "Break a leg"), cultural expressions, or slang.
Return ONLY a valid JSON object matching this structure:
{
  "translatedText": "Natural, context-aware translation in the target language preserving tone and intent",
  "literalTranslation": "Direct word-for-word translation showing how literal translation differs from intended meaning",
  "intendedMeaning": "Clear explanation of what the speaker actually means",
  "formalityLevel": "casual | polite | formal",
  "culturalContext": "Explanation of cultural context, etiquette, or idiomatic background",
  "alternativePhrases": [
    { "text": "Alternative phrasing 1", "tone": "formal" },
    { "text": "Alternative phrasing 2", "tone": "colloquial" }
  ]
}`;

  try {
    const result = await modelInstance.generateContent(prompt);
    return safeParseJSON(result.response.text());
  } catch (err) {
    console.error('[Gemini Translate Error]:', err.message);
    return {
      translatedText: `[Translation to ${targetLanguage}]: ${text}`,
      literalTranslation: text,
      intendedMeaning: 'Contextual meaning unavailable.',
      formalityLevel: 'auto',
      culturalContext: 'Standard expression.',
      alternativePhrases: [],
    };
  }
};

/**
 * Generate vector embedding for text chunk using text-embedding-004
 */
export const generateEmbedding = async (text) => {
  if (!embeddingModelInstance) {
    return null;
  }
  try {
    const result = await embeddingModelInstance.embedContent(text);
    return result.embedding.values; // 768-dimensional float array
  } catch (err) {
    console.warn('[Gemini Embedding Error]:', err.message);
    return null;
  }
};

/**
 * Summarize older conversation to compress memory and save tokens
 */
export const summarizeConversation = async (messages = []) => {
  if (!modelInstance || messages.length === 0) return '';
  const prompt = `Summarize the key topics, decisions, user preferences, and unresolved questions from this conversation in 3-4 concise bullet points:
${messages.map((m) => `${m.sender}: ${m.text}`).join('\n')}`;

  try {
    const result = await modelInstance.generateContent(prompt);
    return result.response.text().trim();
  } catch (err) {
    return '';
  }
};
