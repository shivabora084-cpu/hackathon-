import { config } from '../config/index.js';

export const getSpeechCapabilities = () => {
  return {
    sttProvider: config.speech.sttProvider,
    ttsProvider: config.speech.ttsProvider,
    browserSupported: true,
    supportedLanguages: [
      { code: 'en-US', name: 'English (US)' },
      { code: 'en-IN', name: 'English (India)' },
      { code: 'ta-IN', name: 'Tamil (India)' },
      { code: 'hi-IN', name: 'Hindi (India)' },
      { code: 'te-IN', name: 'Telugu (India)' },
      { code: 'ml-IN', name: 'Malayalam (India)' },
      { code: 'kn-IN', name: 'Kannada (India)' },
      { code: 'bn-IN', name: 'Bengali (India)' },
    ],
  };
};

export const transcribeAudio = async (audioBuffer, mimeType) => {
  // If external STT (e.g., Google Cloud Speech) is configured, handle here.
  // By default, the frontend uses the high-precision Web Speech API.
  return {
    provider: config.speech.sttProvider,
    transcript: '',
    note: 'Browser Web Speech API is the active low-cost provider.',
  };
};

export const synthesizeSpeech = async (text, language = 'en', voiceOptions = {}) => {
  // Returns instructions and parameters for speech synthesis
  return {
    provider: config.speech.ttsProvider,
    text,
    language,
    speechRate: voiceOptions.speechRate || 1.0,
    speechPitch: voiceOptions.speechPitch || 1.0,
  };
};
