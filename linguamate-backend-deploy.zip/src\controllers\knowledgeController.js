import { supabase } from '../database/supabaseClient.js';
import { processDocument, retrieveRelevantContext } from '../services/ragService.js';
import { generateChatResponse } from '../services/geminiService.js';
import { config } from '../config/index.js';

export const uploadDocument = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, error: 'Please upload a PDF or TXT file.' });
    }

    const { originalname, buffer, size, mimetype } = req.file;
    const userId = req.user?.id || null;
    const bucket = config.supabase.storageBucket;
    const filePath = `documents/${Date.now()}_${originalname.replace(/\s+/g, '_')}`;

    if (!supabase) {
      return res.status(503).json({
        success: false,
        error: 'Supabase storage and database not configured in backend .env',
      });
    }

    // 1. Upload to Supabase Storage
    const { error: storageError } = await supabase.storage
      .from(bucket)
      .upload(filePath, buffer, {
        contentType: mimetype,
        upsert: false,
      });

    if (storageError) {
      console.warn('[Storage Warning]:', storageError.message);
      // Even if storage bucket policies need configuration, we still process the document in database
    }

    // 2. Insert record into knowledge_documents
    const { data: docRecord, error: docError } = await supabase
      .from('knowledge_documents')
      .insert({
        user_id: userId,
        title: originalname.replace(/\.[^/.]+$/, ''),
        filename: originalname,
        file_path: filePath,
        file_size: size,
        mime_type: mimetype,
        status: 'uploaded',
      })
      .select()
      .single();

    if (docError) throw docError;

    // 3. Process document in background (extract, chunk, embed)
    processDocument({
      documentId: docRecord.id,
      fileBuffer: buffer,
      mimeType: mimetype,
      filename: originalname,
    }).catch((err) => {
      console.error('[Background Document Processing Error]:', err);
    });

    return res.status(202).json({
      success: true,
      message: 'Document uploaded and is now being processed for semantic search.',
      document: docRecord,
    });
  } catch (err) {
    next(err);
  }
};

export const getDocuments = async (req, res, next) => {
  try {
    if (supabase) {
      const { data, error } = await supabase
        .from('knowledge_documents')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return res.json({ success: true, documents: data || [] });
    }

    return res.json({ success: true, documents: [] });
  } catch (err) {
    next(err);
  }
};

export const deleteDocument = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (supabase) {
      // Find document to get storage path
      const { data: doc } = await supabase
        .from('knowledge_documents')
        .select('file_path')
        .eq('id', id)
        .single();

      if (doc && doc.file_path) {
        await supabase.storage.from(config.supabase.storageBucket).remove([doc.file_path]);
      }

      const { error } = await supabase
        .from('knowledge_documents')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return res.json({ success: true, message: 'Document deleted successfully' });
    }

    return res.json({ success: true });
  } catch (err) {
    next(err);
  }
};

export const queryKnowledge = async (req, res, next) => {
  try {
    const { query, language = 'en' } = req.body;
    if (!query) {
      return res.status(400).json({ success: false, error: 'Query is required.' });
    }

    const { contextText, sources } = await retrieveRelevantContext(query);
    const answer = await generateChatResponse({
      userMessage: query,
      preferredLanguage: language,
      documentContext: contextText,
    });

    return res.json({
      success: true,
      query,
      answer: answer.text,
      sources,
      hasContext: Boolean(contextText),
    });
  } catch (err) {
    next(err);
  }
};
