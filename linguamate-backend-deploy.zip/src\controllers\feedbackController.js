import { supabase } from '../database/supabaseClient.js';

export const submitFeedback = async (req, res, next) => {
  try {
    const { conversationId, messageId, rating, comment } = req.body;
    const userId = req.user?.id || null;

    if (supabase) {
      const { data, error } = await supabase
        .from('feedback')
        .insert({
          user_id: userId,
          conversation_id: conversationId,
          message_id: messageId,
          rating,
          comment,
        })
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json({ success: true, message: 'Feedback submitted successfully', feedback: data });
    }

    return res.status(201).json({ success: true, message: 'Feedback recorded (local)' });
  } catch (err) {
    next(err);
  }
};
