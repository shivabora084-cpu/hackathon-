import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { supabase } from '../database/supabaseClient.js';
import { config } from '../config/index.js';

// In-memory fallback if Supabase is temporarily unreachable during first run
const localProfiles = new Map();
const localPreferences = new Map();

export const register = async (req, res, next) => {
  try {
    const { email, password, fullName, preferredLanguage, role } = req.body;
    const normalizedEmail = email.toLowerCase().trim();
    const passwordHash = await bcrypt.hash(password, 10);

    if (supabase) {
      // 1. Check if user already exists
      const { data: existingUser } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', normalizedEmail)
        .single();

      if (existingUser) {
        return res.status(409).json({
          success: false,
          error: 'An account with this email already exists.',
        });
      }

      // 2. Insert into profiles
      const { data: newProfile, error: profileError } = await supabase
        .from('profiles')
        .insert({
          email: normalizedEmail,
          password_hash: passwordHash,
          full_name: fullName,
          preferred_language: preferredLanguage || 'en',
          role: role || 'user',
        })
        .select()
        .single();

      if (profileError) throw profileError;

      // 3. Create default preferences
      await supabase.from('user_preferences').insert({
        user_id: newProfile.id,
        target_language: preferredLanguage || 'en',
      });

      // 4. Generate JWT
      const token = jwt.sign(
        { id: newProfile.id, email: newProfile.email, role: newProfile.role },
        config.jwt.secret,
        { expiresIn: config.jwt.expiresIn }
      );

      return res.status(201).json({
        success: true,
        message: 'Account created successfully',
        token,
        user: {
          id: newProfile.id,
          email: newProfile.email,
          fullName: newProfile.full_name,
          role: newProfile.role,
          preferredLanguage: newProfile.preferred_language,
        },
      });
    }

    // Fallback store
    if (localProfiles.has(normalizedEmail)) {
      return res.status(409).json({ success: false, error: 'User already exists' });
    }
    const mockId = 'mock-' + Date.now();
    const mockUser = {
      id: mockId,
      email: normalizedEmail,
      passwordHash,
      full_name: fullName,
      role: role || 'user',
      preferred_language: preferredLanguage || 'en',
    };
    localProfiles.set(normalizedEmail, mockUser);
    const token = jwt.sign({ id: mockId, email: normalizedEmail, role: mockUser.role }, config.jwt.secret);

    return res.status(201).json({
      success: true,
      message: 'Account created (in-memory mode: connect Supabase for persistent DB)',
      token,
      user: {
        id: mockId,
        email: normalizedEmail,
        fullName,
        role: mockUser.role,
        preferredLanguage: mockUser.preferred_language,
      },
    });
  } catch (err) {
    next(err);
  }
};

export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const normalizedEmail = email.toLowerCase().trim();

    if (supabase) {
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('email', normalizedEmail)
        .single();

      if (error || !profile) {
        return res.status(401).json({
          success: false,
          error: 'Invalid email or password.',
        });
      }

      const isValidPassword = await bcrypt.compare(password, profile.password_hash);
      if (!isValidPassword) {
        return res.status(401).json({
          success: false,
          error: 'Invalid email or password.',
        });
      }

      const token = jwt.sign(
        { id: profile.id, email: profile.email, role: profile.role },
        config.jwt.secret,
        { expiresIn: config.jwt.expiresIn }
      );

      return res.json({
        success: true,
        message: 'Logged in successfully',
        token,
        user: {
          id: profile.id,
          email: profile.email,
          fullName: profile.full_name,
          role: profile.role,
          preferredLanguage: profile.preferred_language,
        },
      });
    }

    // Fallback
    const mockUser = localProfiles.get(normalizedEmail);
    if (!mockUser || !(await bcrypt.compare(password, mockUser.passwordHash))) {
      return res.status(401).json({ success: false, error: 'Invalid email or password' });
    }
    const token = jwt.sign({ id: mockUser.id, email: mockUser.email, role: mockUser.role }, config.jwt.secret);
    return res.json({
      success: true,
      token,
      user: {
        id: mockUser.id,
        email: mockUser.email,
        fullName: mockUser.full_name,
        role: mockUser.role,
        preferredLanguage: mockUser.preferred_language,
      },
    });
  } catch (err) {
    next(err);
  }
};

export const getMe = async (req, res, next) => {
  try {
    const userId = req.user.id;

    if (supabase) {
      const { data: profile, error: profileErr } = await supabase
        .from('profiles')
        .select('id, email, full_name, role, preferred_language, created_at')
        .eq('id', userId)
        .single();

      if (profileErr || !profile) {
        return res.status(404).json({ success: false, error: 'User profile not found.' });
      }

      const { data: preferences } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', userId)
        .single();

      return res.json({
        success: true,
        user: profile,
        preferences: preferences || {
          speech_rate: 1.0,
          speech_pitch: 1.0,
          selected_voice: 'default',
          theme: 'dark',
          target_language: profile.preferred_language || 'en',
        },
      });
    }

    return res.json({
      success: true,
      user: { id: req.user.id, email: req.user.email, role: req.user.role, full_name: 'LinguaMate User' },
      preferences: { speech_rate: 1.0, theme: 'dark', target_language: 'en' },
    });
  } catch (err) {
    next(err);
  }
};

export const updatePreferences = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const updates = req.body;

    if (supabase) {
      const { data, error } = await supabase
        .from('user_preferences')
        .upsert({
          user_id: userId,
          speech_rate: updates.speechRate,
          speech_pitch: updates.speechPitch,
          selected_voice: updates.selectedVoice,
          target_language: updates.targetLanguage,
          theme: updates.theme,
          auto_play_audio: updates.autoPlayAudio,
          updated_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (error) throw error;
      return res.json({ success: true, message: 'Preferences updated', preferences: data });
    }

    return res.json({ success: true, message: 'Preferences updated (local)', preferences: updates });
  } catch (err) {
    next(err);
  }
};
