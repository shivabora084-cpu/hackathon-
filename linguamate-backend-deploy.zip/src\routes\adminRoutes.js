import { Router } from 'express';
import {
  getAnalytics,
  getAllUsers,
  getAllConversations,
  getSystemHealth,
} from '../controllers/adminController.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';

const router = Router();

router.use(authenticateToken, requireAdmin);

router.get('/analytics', getAnalytics);
router.get('/users', getAllUsers);
router.get('/conversations', getAllConversations);
router.get('/system-health', getSystemHealth);

export default router;
