import { createClient } from '@supabase/supabase-js';
import { config } from '../config/index.js';

let supabaseInstance = null;

if (config.supabase.url && (config.supabase.serviceRoleKey || config.supabase.anonKey)) {
  const key = config.supabase.serviceRoleKey || config.supabase.anonKey;
  supabaseInstance = createClient(config.supabase.url, key, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}

export const supabase = supabaseInstance;

/**
 * Health check for Supabase database connection
 */
export const testDatabaseConnection = async () => {
  if (!supabaseInstance) {
    return {
      connected: false,
      message: 'Supabase credentials not configured in backend environment variables.',
      tables: [],
    };
  }

  try {
    const { data, error } = await supabaseInstance
      .from('profiles')
      .select('count', { count: 'exact', head: true });

    if (error) {
      return {
        connected: false,
        message: `Supabase query error: ${error.message}`,
        details: error,
      };
    }

    return {
      connected: true,
      message: 'Successfully connected to Supabase PostgreSQL database.',
    };
  } catch (err) {
    return {
      connected: false,
      message: `Failed to connect to Supabase: ${err.message}`,
    };
  }
};
